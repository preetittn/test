package spring.eshopping;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EshoppingApplicationTests {

	@Test
	void contextLoads() {
	}

}
