package spring.eshopping.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import spring.eshopping.dtos.CategoryMetadataDTO;
import spring.eshopping.entities.category.Category;
import spring.eshopping.entities.category.CategoryMetadataField;
import spring.eshopping.entities.category.CategoryMetadataFieldValues;
import spring.eshopping.exception.ResourceNotFoundException;
import spring.eshopping.repositories.CategoryMetadataFieldRepo;
import spring.eshopping.repositories.CategoryMetadataFieldValuesRepo;
import spring.eshopping.repositories.CategoryRepo;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

@Service
public class CategoryMetadataService {

    @Autowired
    CategoryRepo categoryRepo;

    @Autowired
    CategoryMetadataFieldRepo metadataRepo;

    @Autowired
    CategoryMetadataFieldValuesRepo valuesRepo;

    public String addCategoryMetadata(CategoryMetadataDTO categoryMetadataDTO) {
        System.out.println(categoryMetadataDTO);
        Optional<Category> category = categoryRepo.findById(categoryMetadataDTO.getCategoryId());
        System.out.println(category.get()+"-----------");
        if (!category.isPresent()) {
            return categoryMetadataDTO.getCategoryId() + " category does not exist";
        }
        HashMap<String, HashSet<String>> filedIdValues = categoryMetadataDTO.getFiledIdValues();
        Set<String> metadataIds = filedIdValues.keySet();
        metadataIds.forEach(id->{
            Optional<CategoryMetadataField> metadata = metadataRepo.findById(Long.parseLong(id));
            if (!metadata.isPresent()) {
                throw new ResourceNotFoundException(id + " metadata filed does not exist");
            }
        });
        metadataIds.forEach(id->{
            if (filedIdValues.get(id).isEmpty()) {
                throw new ResourceNotFoundException("any one filed does not have values");
            }
        });
        CategoryMetadataFieldValues fieldValues = new CategoryMetadataFieldValues();
        fieldValues.setCategory(category.get());
        System.out.println(metadataIds);
        metadataIds.forEach(id->{
            int count=0;
            Optional<CategoryMetadataField> metadata = metadataRepo.findById(Long.parseLong(id));
            fieldValues.setCategoryMetadataField(metadata.get());
            HashSet<String> values = filedIdValues.get(id);
            String value= String.join(",",values);
            fieldValues.setValue(value);
            metadata.get().getCategoryMetadataFieldValues().add(fieldValues);
            metadataRepo.save(metadata.get());
            count++;
            System.out.println(count+"__________________");
        });
        category.get().getCategoryMetadataFieldValues().add(fieldValues);

//        categoryRepo.save(category.get());
//        valuesRepo.save(fieldValues);
        System.out.println();
        return "Success";
    }
}
