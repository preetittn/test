package spring.eshopping.repositories;

import org.springframework.data.repository.CrudRepository;
import spring.eshopping.entities.product.ProductVariation;

public interface ProductVariationRepo extends CrudRepository<ProductVariation,Long> {
}
