package spring.eshopping.repositories;


import org.springframework.data.repository.CrudRepository;
import spring.eshopping.entities.category.CategoryMetadataField;

public interface CategoryMetadataFieldRepo extends CrudRepository<CategoryMetadataField,Long> {
    CategoryMetadataField findByName(String name);
}
